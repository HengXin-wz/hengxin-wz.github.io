<?php
session_start();

// 随机生成4位数字验证码
$code = rand(1000, 9999);

// 将验证码保存在session中
$_SESSION['captcha'] = $code;

// 创建一张空白验证码图片
$image = imagecreate(70, 30);

// 设置背景颜色为白色
$bgColor = imagecolorallocate($image, 255, 255, 255);

// 设置文本颜色为黑色
$textColor = imagecolorallocate($image, 0, 0, 0);

// 在图片上写入验证码文本
imagestring($image, 5, 10, 10, $code, $textColor);

// 在图片上添加干扰线和噪点
for ($i = 0; $i < 5; $i++) {
    $lineColor = imagecolorallocate($image, rand(0, 255), rand(0, 255), rand(0, 255));
    imageline($image, rand(0, 70), rand(0, 30), rand(0, 70), rand(0, 30), $lineColor);
    $noiseColor = imagecolorallocate($image, rand(0, 255), rand(0, 255), rand(0, 255));
    for ($j = 0; $j < 50; $j++) {
        imagesetpixel($image, rand(0, 70), rand(0, 30), $noiseColor);
    }
}


// 设置Content-Type头部为图像类型
header('Content-Type: image/png');

// 输出图像
imagepng($image);

// 销毁图像资源
imagedestroy($image);
?>
