<?php 
$link=mysqli_connect("localhost","a_cn","Wz20100807"); 
if(!$link) echo "FAILD!连接错误，用户名密码不对"; 
else echo "OK!可以连接"; 
?> 