<?php
$dbhost = "127.0.0.1";
$dbuser = 'a_cn';
$dbname = "a_cn";	//数据库名称
$dbtable='denglu';
$dbpass = "Wz20100807";	//数据库密码
$conn=mysqli_connect($dbhost,$dbuser,$dbpass);
if($conn=mysqli_connect($dbhost,$dbuser,$dbpass)){
    echo "<script type='text/javascript'>alert('连接成功');</script>";
}
else{
    echo "<script type='text/javascript'>alert('连接失败');</script>";
}
$connt=mysqli_select_db($conn,$dbname);
?>