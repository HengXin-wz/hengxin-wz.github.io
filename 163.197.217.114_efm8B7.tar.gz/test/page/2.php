<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Your Website</title>
    <!-- Include the Baidu Translate API script -->
    <script type="text/javascript" src="https://cdn.bootcdn.net/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script type="text/javascript" src="https://fanyi-api.baidu.com/api/trans/vip/translate"></script>
</head>
<body>
    <!-- Your website content -->
    <div id="translationResult"></div>

    <script type="text/javascript">
        // Function to perform translation
        function translateText() {
            var appid = '20240121001947248';
            var key = 'CkGNqNUdJ1SafdjrhYpn';

            // Your text to be translated
            var sourceText = 'Hello, this is a test.';
            console.log('Starting translation request...');

            // Make the API request
            $.get('https://fanyi-api.baidu.com/api/trans/vip/translate', {
                q: sourceText,
                appid: appid,
                salt: Date.now(),
                from: 'en',
                to: 'zh',
                sign: MD5(appid + sourceText + salt + key)
            }, function(data) {
                console.log('Translation response:', data);
                // Display the translation result
                $('#translationResult').text(data.trans_result[0].dst);
            });
        }

        // Function to generate MD5 hash (you may need to include an MD5 library)
        function MD5(value) {
            // Implement your MD5 hash generation logic here
        }
    </script>
</body>
</html>
