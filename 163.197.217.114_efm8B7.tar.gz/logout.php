<?php
// 开启session
session_start();

// 清除用户登录状态
unset($_SESSION['user']);

// 跳转回登录页面或其他你希望用户退出后跳转的页面
header("Location: login.php");
exit();
?>
