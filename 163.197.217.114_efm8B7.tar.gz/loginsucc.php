<!DOCTYPE html>
<html>
<head>
    <title>登录成功</title>
    <meta charset="UTF-8">
    <style>
        body {
            background-image: url("https://baotangguo.cn:8081/");
            font-size: 14px;
            margin: 0; /* Added to remove default margin */
            padding: 0; /* Added to remove default padding */
        }
    </style>
</head>
<body>
<div>
    <?php
    // 开启session
    session_start();

    // 声明变量
    $username = isset($_SESSION['user']) ? $_SESSION['user'] : "";

    // 判断session是否为空
    if (!empty($username)) {
        ?>
        <h1>登录成功！</h1>
        欢迎您！<?php echo $username; ?>
        <br/>
        <a href="logout.php">退出</a> <!-- 修正退出链接 -->
        <?php
    } else {
        // 未登录，无权访问
        ?>
        <title>请登录</title>
        <br/><br/><br/><br/><br/>
        <h1><center><a href="login.php" class="link">你还没有登录</a></center></h1>
        <?php
    }
    ?>
</div>
</body>
</html>
