<?php
session_start();

$err = isset($_GET["err"]) ? $_GET["err"] : "";
$loginAttempts = isset($_SESSION["loginAttempts"]) ? $_SESSION["loginAttempts"] : 0;

// 更新错误信息和登录失败次数
if ($err == 1) {
    $loginAttempts++;
} else if ($err == 2) {
    $loginAttempts = 0; // 重置登录失败次数
}

// 将登录失败次数保存在 session 中
$_SESSION["loginAttempts"] = $loginAttempts1;

// 如果页面被刷新，则重置 err 的值为空
if (!isset($_GET["err"]) && $loginAttempts == 0) {
    $err = "";
}

// 检查是否启用验证码
$enableCaptcha = false;  // 根据需要设置为 true 或 false

// 如果启用验证码，并且登录尝试次数大于等于 3，则生成验证码
if ($enableCaptcha && $loginAttempts1 >= 3) {
    $_SESSION["captcha"] = true;
} else {
    $_SESSION["captcha"] = false;
}
?>

<!DOCTYPE html>
<html lang="zh">
<head>
    <title>登录</title>
    <meta charset="UTF-8">
    <link href="../link/css/styles/login.css" rel="stylesheet">
    <link href="../link/css/styles/background.css" rel="stylesheet">
    <link href="../link/css/styles/dropdown.css" rel="stylesheet">
</head>
<body>
    <?php include '../link/php/dropdown.php'; ?>
    <div id="bigBox">
        <h1>登录页面</h1>
        <div>
            <form id="loginform" action="loginaction.php" method="post">
                <div class="inputBox">
                    <div class="inputText">
                        <label for="name"></label>
                        <input type="text" id="name" name="username" placeholder="用户名" value="<?php echo ($err == 1 || $err == 2) ? $_GET['username'] : ''; ?>">
                    </div>
                    <div class="inputText">
                        <label for="password"></label>
                        <input type="password" id="password" name="password" placeholder="密码" value="<?php echo ($err == 1 || $err == 2) ? $_GET['password'] : ''; ?>">
                    </div>
                </div>
                <div style="color: red; font-size: 12px">
                    <?php
                    switch ($err) {
                        case 1:
                            echo "用户名或密码错误！";
                            break;
                        case 2:
                            echo "用户名或密码不能为空！";
                            break;
                        case 3:
                            echo "验证码不正确！";
                            break;
                    } ?>
                </div>
                <?php
                if ($_SESSION["captcha"]) {
                    // 添加数字验证码的代码
                    echo '<div class="inputText">
                            <img src="captcha.php" alt="验证码">
                            <label for="captcha"></label>
                            <input type="text" id="captcha" name="captcha" placeholder="验证码">
                          </div>';
                }
                ?>
                <p><a href="#" style="color: white">忘记密码?</a></p>
                <input type="submit" id="login" name="login" value="登录" class="loginButton m-left" />
                <input type="button" onclick="location.href='register.php'" id="register" name="register" value="注册" class="loginButton" />
            </form>
        </div>
    </div>
</body>
</html>
