<!DOCTYPE html>
<html lang='zh-CN'>
<head>
    <meta charset="utf-8">
    <link href="../link/styles/css/background.css" rel="stylesheet">
    <link href="../link/styles/css/dropdown.css" rel="stylesheet">
    <link href="../link/styles/css/layout.css" rel="stylesheet">
    <title>恒馨工作室</title>
</head>
<body>
<div class="container">
    <?php include './card/session-check.php'; ?>
    <nav>
      <ul class="dropdown">
          <li><a href="zhuye.html">主页</a></li>
          <li style="float: right"><a href="Login.html">登录</a></li>
      </ul>
    </nav>
    <main class="row">
        <section class="main-column">
            <?php include './card/articles.php'; ?>
        </section>
        <aside class="right-column">
            <?php include './card/sidebar.php'; ?>
        </aside>
    </main>
</div>
</body>
</html>
