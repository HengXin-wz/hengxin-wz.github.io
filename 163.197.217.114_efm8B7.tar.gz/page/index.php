<!doctype html>

<?php
header("Cache-Control: max-age=3600");
header_remove("Expires");
?>



<html lang="zh-CN">
<head>
    <meta charset="utf-8">
    <title>恒馨工作室</title>
    <!--<meta name="viewport" content="width=device-width, initial-scale=1">-->
    <link href="../link/styles/css/dropdown.css" rel="stylesheet">
    <link href="../link/styles/css/background.css" rel="stylesheet">
    <!-- 引入 jQuery -->
    <!--<script src="https://code.jquery.com/jquery-3.6.4.min.js"></script>-->
    
    <!--<script src="https://cdnjs.cloudflare.com/ajax/libs/blueimp-md5/2.18.0/js/md5.min.js"></script>-->
    <!-- 在 jQuery 之后引入 translate.js -->
    <!--<script src="translate.js"></script>-->
    <style type="text/css">
        body{
            /*文字颜色*/
            color: #FFFFFF;
        }
        
        /*正文背景颜色*/
        .zhengwen {
            width: 30%;
            margin: 13% 30% 0;
            background-color: #202326B3;
            padding: 2% 5%;
            border-radius: 10px;
        }
    </style>
</head>
<body>
    <?php include '../link/php/dropdown.php'; ?>
    <div class="zhengwen">
        <h1>这里是恒馨工作室</h1>
        <h4>成立于2023年4月29日</h4>
        我们欢迎您的到来<br/>
        也欢迎您加入我们<br/>
        如果你想进一步访问或参观我们的网站，请先<a style="color: #3390FD" href="login.php">登录</a><!--或<a href="zhuye.php">访客登录</a><br/>-->
        <br/>
        <h3>联系我们</h3>
        QQ:<br/>
        微信:<br/>
    </div>
</body>
</html>