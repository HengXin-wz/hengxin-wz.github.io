<!DOCTYPE html>
<html>
<head>
    <title>注册</title>
    <link rel="stylesheet" href="../link/style/css/register.css">
    <meta charset="UTF-8">
</head>
<body>
<div id="bigBox">
    <h1>注册页面</h1>
<?php
    $username = isset($_POST['username']) ? $_POST['username'] : "";
    $password = isset($_POST['password']) ? $_POST['password'] : "";
    $err = isset($_GET['err']) ? $_GET['err'] : "";
?>
    <form action="deletuseraction.php" method="post">
        <div class="inputBox">
            <div class="inputText">
                <p><input type="text" id="id_name" name="username" required placeholder="用户名" value="<?php echo $username; ?>"></p>
                <p><input type="password" id="password" name="password" required placeholder="密码" value="<?php echo $password; ?>"></p>
                <p><input type="password" id="re_password" name="re_password" required placeholder="重复密码"></p>
                <input type="submit" id="register" name="register" value="注册" class="loginButton m-left">
                <input type="reset" id="reset" name="reset" value="重置" class="loginButton">
            </div>
            <p style="color: white; font-size: 12px">
            <!--提示信息-->
            <?php
                switch ($err) {
                    case 1:
                        echo "用户名已存在！";
                        break;
                    case 2:
                        echo "密码与重复密码不一致！";
                        break;
                    case 3:
                        echo "注册成功！";
                        break;
                }
            ?>
            </p>
        </div>
        <div class="register">
            <a href="login.php" style="color: white">已有账号，去登录</a>
        </div>
    </form>
</div>
</body>
</html>
