<?php
session_start(); //声明变量
$username = isset($_SESSION['user']) ? $_SESSION['user'] : ""; //判断session是否为空
if (!empty($username)) { ?>
    <h1>登录成功！</h1> 欢迎您！<br/>
    <?php echo $username; ?>
    <br/>
    <a href="login.php">退出</a> 
<?php } else {  ?>
    <title>请登录</title>
    <h1>
        <center>
            <a href="login.php" class="link">你还没有登录</a>
        </center>
    </h1> 
<?php } ?>
