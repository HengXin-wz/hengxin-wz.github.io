<div class="card">
   <h2>关于我们</h2>
   <p>这是一个小小的mc服务器官网</p>
   ...
</div>
<div class="card">
    <h3>热门文章</h3>
    ...
</div>
<div class="card">
    <h3>关注我们</h3>
    <p>一些文本...</p>
</div>
