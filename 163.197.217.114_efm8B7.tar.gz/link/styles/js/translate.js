// translate.js

// 生成 UUID
function generateUUID() {
    return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
        var r = Math.random() * 16 | 0,
            v = c == 'x' ? r : (r & 0x3 | 0x8);
        return v.toString(16);
    });
}

// SHA-256 算法
async function sha256(input) {
    // 将字符串编码为 Uint8Array
    const encoder = new TextEncoder();
    const data = encoder.encode(input);

    // 使用 SubtleCrypto 计算 SHA-256
    const hashBuffer = await crypto.subtle.digest('SHA-256', data);

    // 将 ArrayBuffer 转换为十六进制字符串
    const hashArray = Array.from(new Uint8Array(hashBuffer));
    const hashHex = hashArray.map(byte => byte.toString(16).padStart(2, '0')).join('');

    return hashHex;
}

function translateText(language) {
    // 获取需要翻译的文本
    var elementsToTranslate = document.querySelectorAll('[data-lang]');
    
    // 设置翻译后的语言
    var targetLanguage = language || 'en-US'; // 默认为中文

    // 通过调用翻译API进行翻译
    elementsToTranslate.forEach(function(element) {
        var sourceText = element.getAttribute('data-lang');
        // 调用翻译函数并更新元素内容
        translateElement(element, sourceText, targetLanguage);
    });
}

function translateElement(element, sourceText, targetLanguage) {
    // 在这里调用你选择的翻译API进行翻译
    // 以有道翻译API为例，注意替换为你自己的应用密钥和签名逻辑
    // 这里使用了假设的有道翻译API调用，实际应替换为真实的API调用
    var translatedText = realYoudaoTranslateAPI(sourceText, targetLanguage);
    
    // 更新元素内容
    element.textContent = translatedText;
}

function realYoudaoTranslateAPI(sourceText, targetLanguage) {
    var appKey = '0243aa3a2ac6bb37'; // 替换为你的应用ID
    var appSecret = 'WHiMna3FqDyyzDET8ryBd9p2JNGx7jrI'; // 替换为你的应用密钥

    // 生成 UUID 作为 salt
    var salt = generateUUID();

    // 获取当前UTC时间戳（秒）
    var curtime = Math.floor(Date.now() / 1000);

    // 构建 input
    var input;
    if (sourceText.length > 20) {
        input = sourceText.substring(0, 10) + sourceText.length + sourceText.substring(sourceText.length - 10);
    } else {
        input = sourceText;
    }

    // 计算签名
    var signInput = appKey + truncateString(input, 10) + salt + curtime + appSecret;
    var sign = await sha256(signInput);

    // 构建请求参数
    var apiParams = {
        q: sourceText,
        from: 'auto', // 自动检测源语言
        to: targetLanguage,
        appKey: appKey,
        salt: salt,
        signType: 'v3',
        curtime: curtime,
        sign: sign
    };

    // 构建请求 URL
    var apiUrl = 'https://openapi.youdao.com/api';
    var urlWithParams = apiUrl + '?' + new URLSearchParams(apiParams);

    // 发送实际的 API 请求
    return fetch(urlWithParams)
        .then(response => response.json())
        .then(data => {
            // 检查是否存在 translation 属性
            if (data.translation) {
                // 提取翻译结果
                var translation = data.translation[0];
                return translation;
            } else {
                console.error('Translation data is invalid:', data);
                return sourceText; // 返回原文作为默认值
            }
        })
        .catch(error => {
            console.error('Error during translation:', error);
            return sourceText; // 返回原文作为默认值
        });
}

// 辅助函数：截取字符串前N个字符
function truncateString(str, maxLength) {
    return str.length > maxLength ? str.substring(0, maxLength) : str;
}
