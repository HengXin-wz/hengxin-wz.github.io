<div class="dropdown-a">
    <a class="dropbtn" href="page/login.php">登录</a>
    <div class="dropdown"><!--dropdown下拉鼠标区域-->
        <button class="dropbtn">语言/Language</button>
        <div class="dropdown-content">
            <a href="">英语/English</a>
        </div>
    </div>
</div>