<?php
$username = isset($_POST['username']) ? $_POST['username'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";
$remember = isset($_POST['remember']) ? $_POST['remember'] : "";
$sqldel = "DELETE FROM `a_cn`.`usertext` WHERE `usertext`.`id` = 1";

$conn = mysqli_connect("localhost:3307", "hengxin", "Wz20100807", "hengxin");
if (!$conn) {
    die("不能连接到数据库: " . mysqli_connect_error());
}
else {
    mysqli_query($conn, $sqldel);
}

