<?php
header("Content-Type: text/html;charset=UTF-8");
$username = isset($_POST['username']) ? $_POST['username'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";
$re_password = isset($_POST['re_password']) ? $_POST['re_password'] : "";

$con = mysqli_connect("127.0.0.1:3307", "hengxin", "Wz20100807", "hengxin"); //连接数据库
var_dump($con);
mysqli_set_charset($con, "utf8mb4");

if (!$con) {
    die("数据库连接失败: " . mysqli_connect_error());
}

if ($password == $re_password) {
    $sql_select = "SELECT username FROM usertext WHERE username = '$username'";
    $ret = mysqli_query($con, $sql_select);
    $row = mysqli_fetch_array($ret);

    if ($username == $row['username']) {
        header("Location:register.php?err=1");
    } else {
        $sql_insert = "INSERT INTO usertext(username,password,sex,qq,email,phone,address)
                       VALUES('$username','$password','$sex','$qq','$email','$phone','$address')";
        mysqli_query($con, $sql_insert);
        
        header("Location:register.php?err=3");
    }
}
else {
    header("Location:register.php?err=2");
}
$result = mysqli_query($con, $sql_insert);
if (!$result) {
    die("注册失败: " . mysqli_error($con));
}

mysqli_close($con);
?>
