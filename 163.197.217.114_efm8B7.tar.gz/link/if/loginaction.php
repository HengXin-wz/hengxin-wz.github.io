<?php
header("Content-Type: text/html; charset=utf-8");

// 开启会话
session_start();

// 获取表单提交的数据
$username = isset($_POST['username']) ? $_POST['username'] : "";
$password = isset($_POST['password']) ? $_POST['password'] : "";
$remember = isset($_POST['remember']) ? $_POST['remember'] : "";

// 如果用户名和密码都不为空
if (!empty($username) && !empty($password)) {
    // 连接数据库
    $conn = mysqli_connect("localhost:3307", "hengxin", "Wz20100807", "hengxin");
    if (!$conn) {
        die("不能连接到数据库: " . mysqli_connect_error());
    }

    // 设置数据库字符集
    mysqli_set_charset($conn, "utf8mb4");

    // 构建查询语句
    $sql_select = "SELECT username, password FROM usertext WHERE username = '$username' AND password = '$password'";
    $result = mysqli_query($conn, $sql_select);
    $row = mysqli_fetch_assoc($result);

    // 验证用户名和密码
    if ($row && $username == $row['username'] && $password == $row['password']) {
        // 验证码验证逻辑
        if (isset($_SESSION['captcha']) && $_POST['captcha'] == $_SESSION['captcha']) {
            // 记住登录状态
            if ($remember == "on") {
                // 创建cookie
                setcookie("username", $username, time() + 1 * 12 * 3600);
            }

            $_SESSION['user'] = $username;

            // 写入日志
            $ip = $_SERVER['REMOTE_ADDR'];
            $date = date('Y-m-d H:i:s');
            $info = sprintf("当前访问用户：%s, IP地址：%s, 时间：%s\n", $username, $ip, $date);
            $sql_logs = "INSERT INTO logs(username, ip, date) VALUES('$username', '$ip', '$date')";

            // 日志写入文件
            $logFile = './logs/' . date('Ymd') . '.log';
            $f = fopen($logFile, 'a+');
            if ($f) {
                fwrite($f, $info);
                fclose($f);
            } else {
                echo "无法写入日志文件";
            }

            header("Location: zhuye.php");
        } else {
            // 验证码不正确，跳转到登录页面，带上错误信息
            header("Location: login.php?err=3");
        }
    } else {
        // 用户名或密码错误，跳转到登录页面，带上错误信息
        header("Location: login.php?err=1");
    }

    // 关闭数据库连接
    mysqli_close($conn);
} else {
    // 用户名或密码为空，跳转到登录页面，带上错误信息
    header("Location: login.php?err=2");
}
?>
